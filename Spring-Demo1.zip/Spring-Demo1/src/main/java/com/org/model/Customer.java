package com.org.model;

public class Customer {
	
	private String customerId;
	private String customerName;
	private String regFees;
	private Address address;
	
	public Customer() {
		
	}
	
	public Customer(String customerId, String customerName, String regFees) {
		super();
		this.customerId = customerId;
		this.customerName = customerName;
		this.regFees = regFees;
	}
	
	

	public Customer(String customerId, String customerName, String regFees, Address address) {
		super();
		this.customerId = customerId;
		this.customerName = customerName;
		this.regFees = regFees;
		this.address = address;
	}

	public String getCustomerId() {
		return customerId;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public String getRegFees() {
		return regFees;
	}

	public void setRegFees(String regFees) {
		this.regFees = regFees;
	}
	
	
	
	public Address getAddress() {
		return address;
	}

	public void setAddress(Address address) {
		this.address = address;
	}

	@Override
	public String toString() {
		return "Customer [customerId=" + customerId + ", customerName=" + customerName + ", regFees=" + regFees
				+ ", address=" + address + "]";
	}

	
	
	
	
	
	
	

}
