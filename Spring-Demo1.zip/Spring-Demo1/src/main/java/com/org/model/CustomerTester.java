package com.org.model;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.context.support.FileSystemXmlApplicationContext;

public class CustomerTester {

	public static void main(String[] args) {
		
		AbstractApplicationContext context=new ClassPathXmlApplicationContext("customerBean.xml");
		//FileSystemXmlApplicationContext context=new FileSystemXmlApplicationContext("D:\\Users\\antpaul\\Desktop\\customerBean");
		
		Customer customer=(Customer) context.getBean("cust");
		//Customer customer1=(Customer) context.getBean("cust");
		//customer1.setCustomerId("1002");
		System.out.println(customer);
		//System.out.println(customer1);
		context.close();

	}

}
